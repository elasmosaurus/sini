
<?php include('db_connect.php');?>
<html lang="en">
<head>
    
</head>
<body >
<div class="jumbotron jumbotron-fluid">
 
  <div class="text-center">
    <h1 class="display-4">Candidates Details</h1>
    <p>.....................................................</a>.</p>
    </div>
</div>

<h2>Voting Lists</h2>
<table class="table">
  <thead class="thead-dark">
    <tr>
      <th scope="col" >#</th>
      <th scope="col" >Voters Name</th>
      <th scope="col" >Votes Proof</th>
    </tr>
  </thead>
  <tbody>
  <?php 
	$i = 1;
	$cats = $conn->query("SELECT * FROM votes order by id asc ");
	while($row=$cats->fetch_assoc()):
	?>
	    <tr>
        <td scope="col"><?php echo $i++ ?></td>
	    <td scope="col"><?php echo $row['vname'] ?></td>
	    <td scope="col"><?php echo $row['proof'] ?></td>
	    </tr>
        <?php endwhile; ?>
  </tbody>
</table>

</body>
