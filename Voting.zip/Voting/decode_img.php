
<!DOCTYPE html>
<html lang="en">
<head>
    
</head>
<body >
<table class="table">
  <thead class="thead-dark">
    <tr>
      <th scope="col">Steganography Image</th>
      <th scope="col">Decode Message</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>Mark</td>
      <td>Otto</td>
    </tr>

  </tbody>
</table>


</table>

</body>
