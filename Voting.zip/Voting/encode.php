<?php

include('functions.php');

// Number of bytes in an integer.
$INTEGER_BYTES = 4;
$BYTE_BITS = 8;

$message = "Hello from outer space, it's your commander speaking.";
$binaryMessage = toBinary($message);
// The number of bits contained in the message, aka the size of the payload as an integer.
$messageLength = strlen($binaryMessage);
// Convert the length to binary as well and make sure to pad it with 32 0's.
$binaryMessageLength = str_pad(decbin($messageLength), $INTEGER_BYTES * $BYTE_BITS, "0", STR_PAD_LEFT);
// 32 string length
// 20 character
// 12 character not fulfill
// 00000000000010010101010

// The payload will incorporate the length and the message.
$payload = $binaryMessageLength.$binaryMessage;

// have own image
$src = 'wilderness.jpg';
$image = imagecreatefromjpeg($src);

$size = getimagesize($src);
$width = $size[0];
$height = $size[1];

function encodePayload(string $payload, $image, $width, $height) {
    $payloadLength = strlen($payload);
    // We are able to store 3 bits per pixel (1 LSB for each color channel) times the width, times the height.
    if($payloadLength > $width * $height * 3) {
        echo "Image not big enough to hold data.";
        return false;
    }
    $bitIndex = 0;
    for($y = 0; $y < $height; $y++) {
        for($x = 0; $x < $width; $x++) {
            $rgb = imagecolorat($image, $x, $y);
            // Each color channel's value is extracted from the original integer.
            $r = ($rgb >> 16) & 0xFF;
            $g = ($rgb >> 8) & 0xFF;
            $b = $rgb & 0xFF;

            // LSB's are cleared by ANDing with 0xFE and filled by ORing with the current payload bit, as long as the payload length isn't hit.
            $r = ($bitIndex < $payloadLength) ? (($r & 0xFE) | $payload[$bitIndex++]) : $r;
            $g = ($bitIndex < $payloadLength) ? (($g & 0xFE) | $payload[$bitIndex++]) : $g;
            $b = ($bitIndex < $payloadLength) ? (($b & 0xFE) | $payload[$bitIndex++]) : $b;

            $color = imagecolorallocate($image, $r, $g, $b);
            imagesetpixel($image, $x, $y, $color);

            if($bitIndex >= $payloadLength) {
                return true;
            }
        }
    }
}

if(encodePayload($payload, $image, $width, $height)) {
    echo 'Payload delivered.'.'<br>';
} else {
    echo 'Something went wrong.'.'<br>';
}

imagepng($image, 'encoded_'. $_SESSION['username'] . '.png');
imagedestroy($image);


?>